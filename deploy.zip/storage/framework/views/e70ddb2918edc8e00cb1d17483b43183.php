<!-- resources/views/components/input.blade.php -->
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['name', 'value' => '', 'placeholder' => ' ', 'class' => '', 'id' => '', 'label' => '', 'error' => '']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['name', 'value' => '', 'placeholder' => ' ', 'class' => '', 'id' => '', 'label' => '', 'error' => '']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<div class="z-0 w-full mb-5 group">
    <label for="first_name" class="block mb-2 text-md text-gray-500 dark:text-gray-400 font-Robotomedium"><?php echo e($label); ?></label>
    <div id="quill-editor-<?php echo e($id); ?>" class="block py-2.5 px-0 w-full text-sm text-gray-900 bg-transparent border-0 border-b-2 border-gray-300 appearance-none dark:text-white dark:border-gray-600 dark:focus:border-blue-500 focus:outline-none focus:ring-0 focus:border-blue-600 peer"></div>

    <textarea
        name="<?php echo e($name); ?>"
        id="<?php echo e($id); ?>"
        class="hidden <?php echo e($class); ?> block py-2.5 px-0 w-full text-sm text-gray-900 bg-transparent border-0 border-b-2 border-gray-300 appearance-none dark:text-white dark:border-gray-600 dark:focus:border-blue-500 focus:outline-none focus:ring-0 focus:border-blue-600 peer"
        placeholder=" "
    ><?php echo e($value); ?></textarea>

    <?php if($error): ?>
        <p class="text-red-600 text-sm mt-2 font-playwrite italic"><?php echo e($error); ?></p>
    <?php endif; ?>
</div>


<?php /**PATH D:\LaravelApiAndWebs\resources\views/components/texteditor.blade.php ENDPATH**/ ?>