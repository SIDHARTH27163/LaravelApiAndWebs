
<?php
    $headingClass = $headingClass ?? 'text-xl font-Robotoregular'; // Default class if none is provided
?>

<h1 class="<?php echo e($headingClass); ?>"><?php echo e($headingText); ?></h1>
<?php /**PATH D:\LaravelApiAndWebs\resources\views/components/heading.blade.php ENDPATH**/ ?>