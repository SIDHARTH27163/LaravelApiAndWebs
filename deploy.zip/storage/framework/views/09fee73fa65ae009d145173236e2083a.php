<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'name',
    'value' => '',
    'placeholder' => ' ',
    'options' => [],
    'class' => '',
    'id' => '',
    'label' => '',
    'error' => '',
    'selected' => ''
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'name',
    'value' => '',
    'placeholder' => ' ',
    'options' => [],
    'class' => '',
    'id' => '',
    'label' => '',
    'error' => '',
    'selected' => ''
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<div class="w-full mx-auto mb-5">
    <?php if($label): ?>
        
    <?php endif; ?>

    <select
        id="<?php echo e($id); ?>"
        name="<?php echo e($name); ?>"
        class="block py-2.5 px-0 w-full text-base font-normal font-Robotoregular text-gray-500 bg-transparent border-0 border-b-2 border-slate-900 appearance-none dark:text-gray-400 dark:border-slate-900 focus:outline-none focus:ring-0 focus:border-slate-900 peer <?php echo e($class); ?>"
    >
        <option disabled selected><?php echo e($placeholder); ?></option>
        <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $optionValue => $optionLabel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($optionValue); ?>" <?php echo e($optionValue == $selected ? 'selected' : ''); ?>>
                <?php echo e($optionLabel); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>

    <?php if($error): ?>
        <p class="text-red-600 text-sm mt-2 font-playwrite italic"><?php echo e($error); ?></p>
    <?php endif; ?>
</div>
<?php /**PATH D:\LaravelApiAndWebs\resources\views/components/selectbox.blade.php ENDPATH**/ ?>