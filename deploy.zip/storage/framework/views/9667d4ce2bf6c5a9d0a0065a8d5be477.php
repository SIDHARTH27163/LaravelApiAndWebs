<?php $__env->startSection('content'); ?>
<div class="p-4 border-2 border-dashed rounded-lg border-gray-700 font-Robotomedium underline">
    <div class="p-3 my-1">
        <?php if(session('success')): ?>
            <?php echo $__env->make('components.success-alert', [
                'class' => 'font-playwrite font-white',
                'msg' => session('success'),
            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
    </div>

admin home
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LaravelApiAndWebs\resources\views/admin/admin.blade.php ENDPATH**/ ?>