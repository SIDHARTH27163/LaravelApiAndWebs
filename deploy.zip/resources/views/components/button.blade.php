@props(['name', 'type' => '', 'value' => '', 'placeholder' => ' ', 'class' => '', 'id' => '', 'label' => ''])

<!-- HTML !-->
<button class="{{$class}}" type="{{$type}}" role="{{$role}}">{{$label}}</button>

