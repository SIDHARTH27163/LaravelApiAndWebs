// app.js
import './bootstrap';
import 'flowbite'; // Import Flowbite if used

import Alpine from 'alpinejs';

window.Alpine = Alpine;

Alpine.start();
